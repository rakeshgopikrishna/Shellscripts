#Requires -Version 5.1
<#
.SYNOPSIS
    One-click AzCopy v10 installer for Windows (PowerShell + Git Bash).

.DESCRIPTION
    Downloads, extracts, and installs AzCopy v10 to the user profile directory.
    Adds it to the permanent PATH for both PowerShell/CMD and Git Bash.
    Handles the UTF-8 encoding fix for .bashrc / .bash_profile automatically.

.EXAMPLE
    # Right-click -> Run with PowerShell
    .\install_azcopy.ps1

    # Or from a terminal:
    powershell -ExecutionPolicy Bypass -File .\install_azcopy.ps1

.NOTES
    Author : Data Engineering
    Date   : 2026-02-19
    Version: 1.1   # Fixed: goto bug, $response scope, Unicode portability
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$installDir = $env:USERPROFILE
$azcopyPath = Join-Path $installDir "azcopy.exe"
$downloadUrl = "https://aka.ms/downloadazcopy-v10-windows"
$tempZip = Join-Path $env:TEMP "azcopy_install.zip"
$tempExtract = Join-Path $env:TEMP "azcopy_install"

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  AzCopy v10 -- One-Click Installer" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# ---- Step 1: Check if already installed ----
$skipDownload = $false
if (Test-Path $azcopyPath) {
    $existingVersion = & $azcopyPath --version 2>$null
    Write-Host "[OK] AzCopy already exists: $existingVersion" -ForegroundColor Yellow
    $response = Read-Host "    Reinstall / update? (y/N)"
    if ($response -notmatch '^[yY]') {
        Write-Host "    Skipping download. Verifying PATH setup..." -ForegroundColor Gray
        $skipDownload = $true
    }
}

if (-not $skipDownload) {
    # ---- Step 2: Download ----
    Write-Host "[1/5] Downloading AzCopy from $downloadUrl ..." -ForegroundColor White
    try {
        # Use TLS 1.2
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -Uri $downloadUrl -OutFile $tempZip -UseBasicParsing
        $sizeMB = [math]::Round((Get-Item $tempZip).Length / 1MB, 1)
        Write-Host "      Downloaded: $sizeMB MB" -ForegroundColor Green
    }
    catch {
        Write-Host "[FAIL] Download failed: $_" -ForegroundColor Red
        exit 1
    }

    # ---- Step 3: Extract ----
    Write-Host "[2/5] Extracting archive ..." -ForegroundColor White
    try {
        if (Test-Path $tempExtract) { Remove-Item $tempExtract -Recurse -Force }
        Expand-Archive -Path $tempZip -DestinationPath $tempExtract -Force
        Write-Host "      Extracted to: $tempExtract" -ForegroundColor Green
    }
    catch {
        Write-Host "[FAIL] Extraction failed: $_" -ForegroundColor Red
        exit 1
    }

    # ---- Step 4: Install ----
    Write-Host "[3/5] Installing to $installDir ..." -ForegroundColor White
    try {
        $exe = Get-ChildItem $tempExtract -Recurse -Filter "azcopy.exe" | Select-Object -First 1
        if (-not $exe) {
            Write-Host "[FAIL] azcopy.exe not found in archive!" -ForegroundColor Red
            exit 1
        }
        Copy-Item $exe.FullName -Destination $azcopyPath -Force
        Write-Host "      Installed: $azcopyPath" -ForegroundColor Green
    }
    catch {
        Write-Host "[FAIL] Install failed: $_" -ForegroundColor Red
        exit 1
    }
}

# ---- Step 5: Add to PowerShell / CMD PATH ----
Write-Host "[4/5] Configuring PATH (PowerShell / CMD) ..." -ForegroundColor White
$userPath = [Environment]::GetEnvironmentVariable("Path", "User")
if ($userPath -split ";" | Where-Object { $_ -eq $installDir }) {
    Write-Host "      Already in user PATH" -ForegroundColor Gray
}
else {
    [Environment]::SetEnvironmentVariable("Path", "$userPath;$installDir", "User")
    $env:PATH += ";$installDir"
    Write-Host "      Added $installDir to permanent user PATH" -ForegroundColor Green
}

# ---- Step 6: Add to Git Bash PATH (.bashrc + .bash_profile) ----
Write-Host "[5/5] Configuring PATH (Git Bash) ..." -ForegroundColor White
$bashDir = "/c/Users/$env:USERNAME"
$exportLine = "export PATH=`"`$PATH:$bashDir`""

foreach ($fileName in @(".bashrc", ".bash_profile")) {
    $filePath = Join-Path $env:USERPROFILE $fileName
    $needsUpdate = $true

    if (Test-Path $filePath) {
        # Read with proper encoding detection
        $bytes = [System.IO.File]::ReadAllBytes($filePath)
        # Detect and read as UTF-8
        $content = [System.Text.Encoding]::UTF8.GetString($bytes).TrimStart([char]0xFEFF).TrimStart([char]0xFFFE)

        if ($content -match [regex]::Escape($exportLine)) {
            Write-Host "      $fileName -- already configured" -ForegroundColor Gray
            $needsUpdate = $false
        }
        else {
            $content = $content.TrimEnd() + "`n" + $exportLine + "`n"
        }
    }
    else {
        $content = $exportLine + "`n"
    }

    if ($needsUpdate) {
        # CRITICAL: Write as UTF-8 WITHOUT BOM -- Bash cannot parse UTF-16 or BOM files
        [System.IO.File]::WriteAllText($filePath, $content, [System.Text.UTF8Encoding]::new($false))
        Write-Host "      $fileName -- updated (UTF-8, no BOM)" -ForegroundColor Green
    }
}

# ---- Cleanup temp files ----
Remove-Item $tempZip -Force -ErrorAction SilentlyContinue
Remove-Item $tempExtract -Recurse -Force -ErrorAction SilentlyContinue

# ---- Verify ----
Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  Verification" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

try {
    $version = & $azcopyPath --version
    Write-Host "[OK] $version" -ForegroundColor Green
    Write-Host ""
    Write-Host "  AzCopy is ready to use!" -ForegroundColor Green
    Write-Host "  * PowerShell / CMD: azcopy --version" -ForegroundColor White
    Write-Host "  * Git Bash: source ~/.bashrc && azcopy --version" -ForegroundColor White
    Write-Host ""
}
catch {
    Write-Host "[FAIL] Verification failed: $_" -ForegroundColor Red
    exit 1
}
