# AzCopy Universal Storage Copy — v3.0

Production-grade, auditable data copy between Azure Storage accounts.
Designed for data engineering teams at scale.

---

## Architecture

```
┌─────────────────┐     Server-Side Copy        ┌─────────────────┐
│  Source Account  │  ════════════════════════>   │  Target Account │
│  (Blob or DFS)  │   Put Block From URL         │  (Blob or DFS)  │
└─────────────────┘   Data stays in Azure        └─────────────────┘
        │                                                │
        │         AzCopy orchestrates                    │
        │         from your local machine                │
        │         (control plane only —                  │
        │          zero data through client)              │
        └─── Endpoint: .blob. or .dfs. ─────────────────┘
```

**Key insight**: For Azure-to-Azure copies, data moves server-side between
storage stamps. Your machine only sends API commands — bandwidth and disk
are not consumed locally.

---

## Quick Start

```bash
# 1. Copy the config template
cp copy_config.env.template copy_config.env

# 2. Edit — paste your SAS tokens and verify paths
code copy_config.env     # or: nano copy_config.env

# 3. Preview (dry run — no data copied)
bash azcopy_production_copy.sh --config ./copy_config.env --dry-run

# 4. Execute
bash azcopy_production_copy.sh --config ./copy_config.env
```

---

## Features

| Feature | Description |
|---|---|
| **One-click execution** | Single command, fully config-driven |
| **3 auth modes** | SAS tokens, Azure AD interactive, Service Principal |
| **Blob + ADLS Gen2** | Supports both `.blob.` and `.dfs.` endpoints |
| **Batch mode** | Copy multiple paths in one run (`;`-separated) |
| **Include / Exclude** | Filter by glob pattern (`*.parquet`, `_SUCCESS`) |
| **Bandwidth cap** | `--cap-mbps` prevents network saturation |
| **Concurrency control** | Tune parallel workers for shared environments |
| **Metadata preservation** | Preserves access tier, content-type, properties |
| **SAS expiry detection** | Warns if token expires soon; blocks if expired |
| **Source reachability** | Verifies connectivity before first copy |
| **Size estimation** | Shows total file count + size before confirmation |
| **Retry + backoff** | Configurable retries with exponential wait |
| **Job resume** | Auto-resumes interrupted AzCopy transfers |
| **Post-copy verification** | Compares source vs target file counts |
| **JSON manifest** | Audit trail written to `logs/manifest_*.json` |
| **Structured logging** | Timestamped, SAS-redacted log files |
| **Interrupt handling** | Ctrl+C sends failure notification cleanly |
| **Notifications** | Teams / Slack webhook on start, success, failure |
| **Dry run** | `--dry-run` previews without copying |
| **CI/CD ready** | `--no-confirm` for automated pipelines |
| **Idempotent** | Safe to re-run (`--overwrite=ifSourceNewer`) |

---

## Usage Examples

### Basic copy
```bash
bash azcopy_production_copy.sh --config ./copy_config.env
```

### Dry run (preview only)
```bash
bash azcopy_production_copy.sh --config ./copy_config.env --dry-run
```

### Incremental sync
```bash
bash azcopy_production_copy.sh --config ./copy_config.env --mode sync
```

### Copy only Parquet files, cap bandwidth at 500 Mbps
```bash
bash azcopy_production_copy.sh --config ./copy_config.env \
  --include-pattern "*.parquet" \
  --exclude-pattern "_SUCCESS;*.crc" \
  --cap-mbps 500
```

### ADLS Gen2 (hierarchical namespace)
```bash
bash azcopy_production_copy.sh --config ./copy_config.env --endpoint dfs
```

### Batch copy (multiple paths in one run)
Set in `copy_config.env`:
```
COPY_PATHS="path/to/table1;path/to/table2;path/to/table3"
```

### CI/CD pipeline (non-interactive)
```bash
bash azcopy_production_copy.sh --config ./copy_config.env --no-confirm
```

### Full CLI override (no config file)
```bash
bash azcopy_production_copy.sh \
  --auth-mode sas \
  --source-account cvproddatalake \
  --source-container data-container \
  --target-account actvaldatalake \
  --target-container data-container \
  --source-sas "sv=2023-11-03&ss=b&srt=sco&..." \
  --target-sas "sv=2023-11-03&ss=b&srt=sco&..." \
  --paths "data/6400/output/data_load/row/parquet/CV_R_SHPR_ATTRIBUTES_HISTORY"
```

---

## Authentication Modes

| Mode | Flag | When to Use |
|---|---|---|
| **SAS Tokens** | `--auth-mode sas` | Default. Paste tokens from Azure Portal. No login needed. |
| **Azure AD** | `--auth-mode aad` | Interactive browser login. Needs `Storage Blob Data Reader/Contributor` RBAC. |
| **Service Principal** | `--auth-mode spn` | Automated/CI. Set `SPN_CLIENT_ID`, `SPN_TENANT_ID`, `SPN_CLIENT_SECRET` in config. |

### Generating SAS Tokens

1. Azure Portal → Storage Account → **Shared access signature**
2. **Source** permissions: `Read`, `List`
3. **Target** permissions: `Read`, `Write`, `Create`, `List`
4. Set expiry ≥ 24 hours from now (the script will warn if < 1 hour)
5. Copy the token (everything after the `?`) into `copy_config.env`

---

## Output Artifacts

Every run produces these in the `logs/` directory:

| File | Contents |
|---|---|
| `azcopy_<RUN_ID>.log` | Full timestamped, SAS-redacted execution log |
| `manifest_<RUN_ID>.json` | JSON audit trail: config, results, paths, duration |
| `azcopy_attempt_*.log` | Per-attempt AzCopy output (for debugging failures) |

### Sample Manifest

```json
{
  "run_id": "20260219T143022Z_12345",
  "version": "3.0.0",
  "status": "SUCCESS",
  "source": { "account": "cvproddatalake", "container": "data-container", "endpoint": "blob" },
  "target": { "account": "actvaldatalake", "container": "data-container", "endpoint": "blob" },
  "results": { "total_paths": 1, "succeeded": 1, "failed": 0, "skipped": 0, "duration_seconds": 47 }
}
```

---

## Files

| File | Purpose |
|---|---|
| `azcopy_production_copy.sh` | Main production script (v3.0) |
| `copy_config.env.template` | Configuration template — copy and edit |
| `install_azcopy.ps1` | One-click AzCopy installer (PowerShell + Git Bash) |
| `logs/` | Auto-created directory for logs and manifests |

---

## Exit Codes

| Code | Meaning |
|---|---|
| **0** | All paths copied and verified successfully |
| **1** | Configuration / argument error |
| **2** | Authentication failure |
| **3** | Pre-flight failed (AzCopy missing, source unreachable, SAS expired) |
| **4** | One or more paths failed to copy |
| **5** | Copy succeeded but post-copy verification failed |
| **99** | Dry run completed (no data copied) |

---

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `AzCopy not found` | Not in PATH | Run `install_azcopy.ps1` or add to PATH manually |
| `SAS token EXPIRED` | Token past expiry | Generate new token in Azure Portal |
| `Cannot reach source` | Wrong account/container, bad SAS, or firewall | Verify names, regenerate SAS, check network rules |
| `401 NoAuthenticationInformation` | SAS missing or malformed | Ensure token contains `sv=` and `sig=` |
| `0 files found` | Wrong path or missing trailing data | Verify the path exists using Azure Storage Explorer |
| `Verification FAILED` | File count mismatch | Re-run; check for concurrent writes at source |
| `Script exits silently` | Unset variable (set -u) | Ensure all required config values are set |

---

## Performance Tuning

| Scenario | Recommended Settings |
|---|---|
| **Max throughput** (dedicated copy window) | `CAP_MBPS=0`, `CONCURRENCY=0` (let AzCopy auto-tune) |
| **Shared network** (don't starve other services) | `CAP_MBPS=500`, `CONCURRENCY=16` |
| **Millions of small files** | `CONCURRENCY=64`, consider `COPY_MODE=sync` |
| **Few large files** (TB-scale) | Default settings work well; AzCopy parallelizes internally |

---

## Prerequisites

1. **AzCopy v10.16+** — Install: `powershell -ExecutionPolicy Bypass -File install_azcopy.ps1`
2. **SAS tokens** or **Azure AD** / **Service Principal** access to both accounts
3. **Bash** — Git Bash (Windows), WSL, Linux, macOS, or Docker

---

## Security Notes

- SAS tokens are **never written to log files or manifests** (auto-redacted)
- SAS tokens **are visible** in the OS process list (`ps aux`) during execution — this is an AzCopy limitation; use Service Principal auth on shared machines
- Config files containing tokens should be in `.gitignore` — `copy_config.env` is excluded by default

---

## Airflow DAG — Parallel Orchestration

For production pipelines, use the Airflow DAG to orchestrate parallel copies.

### Architecture

```
┌─────────────────────────────────────────────────────────────┐
│  Airflow DAG: azcopy_storage_copy                           │
│                                                             │
│  START                                                      │
│    │                                                        │
│    ├── GROUP 1 (parallel) ─┬── copy_shpr_attributes_6400    │
│    │                       ├── copy_transactions_6400       │
│    │                       ├── copy_products_6400           │
│    │                       └── copy_stores_6400             │
│    │                                                        │
│    ├── GROUP 2 (parallel) ─┬── copy_cards_6400              │
│    │                       └── ...                          │
│    │                                                        │
│    └── END_SUMMARY                                          │
│                                                             │
│  Jobs within a group run in PARALLEL                        │
│  Groups run SEQUENTIALLY (1 → 2 → 3)                       │
└─────────────────────────────────────────────────────────────┘
```

### Files

| File | Purpose |
|---|---|
| `azcopy_dag.py` | Airflow DAG — reads JSON, creates parallel tasks |
| `azcopy_jobs.json` | Job definitions — paths, connections, groups |
| `azcopy_production_copy.sh` | Execution engine called by each task |

### JSON Job Config (`azcopy_jobs.json`)

```json
{
  "defaults": { ... },           // Global copy settings
  "connections": {               // Named source→target pairs
    "eu_prod_to_eu_val": {
      "source_account": "cvproddatalake",
      "target_account": "actvaldatalake",
      ...
    }
  },
  "jobs": [                      // Each becomes an Airflow task
    {
      "job_id": "copy_transactions_6400",
      "group": 1,                // Group 1 tasks run in parallel
      "connection": "eu_prod_to_eu_val",
      "paths": ["data/6400/.../CV_R_TRANSACTIONS"],
      "enabled": true
    }
  ]
}
```

### Parallelism Control

| Setting | Where | Effect |
|---|---|---|
| `"group": N` | `azcopy_jobs.json` | Jobs with same group run in parallel |
| `max_active_tasks=8` | `azcopy_dag.py` | Max concurrent tasks across all groups |
| `"cap_mbps"` | Job overrides | Bandwidth limit per job |
| `"concurrency"` | Job overrides | AzCopy worker threads per job |

### Deployment

```bash
# 1. Copy DAG to Airflow DAGs folder (git-sync will handle this)
cp azcopy_dag.py /path/to/dags/

# 2. Copy tooling to worker-accessible path
cp azcopy_production_copy.sh azcopy_jobs.json /opt/airflow/tools/AzCopyTool/

# 3. Set Airflow Variables for credentials (via UI or CLI)
airflow variables set azcopy_eu-prod-to-eu-val_spn_client_id "YOUR_CLIENT_ID"
airflow variables set azcopy_eu-prod-to-eu-val_spn_tenant_id "YOUR_TENANT_ID"
airflow variables set azcopy_eu-prod-to-eu-val_spn_secret     "YOUR_SECRET"

# 4. Trigger the DAG
airflow dags trigger azcopy_storage_copy
```

### Adding a New Copy Job

1. Open `azcopy_jobs.json`
2. Add a new entry to the `"jobs"` array:
   ```json
   {
     "job_id": "copy_my_new_table",
     "description": "My Table — Retailer 9999",
     "enabled": true,
     "group": 1,
     "connection": "eu_prod_to_eu_val",
     "paths": ["data/9999/output/data_load/row/parquet/MY_TABLE"]
   }
   ```
3. Commit and push — git-sync deploys it automatically
4. The DAG picks up the new job on next parse (no code changes needed)
