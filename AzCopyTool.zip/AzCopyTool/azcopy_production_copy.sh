#!/usr/bin/env bash
#===============================================================================
#
#  AzCopy Universal Storage Copy — Production Grade
#
#  Version : 3.0.0
#  Date    : 2026-02-19
#  Author  : Data Engineering — ciValue
#  License : Internal Use Only
#
#  Architecture:
#    ┌────────────┐     Server-Side Copy      ┌────────────┐
#    │   Source    │  ═══════════════════════>  │   Target   │
#    │  Storage    │   (Put Block From URL)    │  Storage    │
#    │  Account    │   Data never touches      │  Account    │
#    └────────────┘   the client machine       └────────────┘
#          │                                         │
#          │  Blob (.blob.) or DFS (.dfs.)           │
#          └─── Endpoint auto-detected ──────────────┘
#
#  Description:
#    Universal, production-grade data copy between Azure Storage accounts.
#    Supports Blob Storage and ADLS Gen2 (DFS) endpoints.  Three auth modes:
#    SAS tokens, Azure AD interactive, and Service Principal.  Built for
#    data engineering teams who need reliable, auditable, zero-touch copies.
#
#  Design Principles:
#    1. ZERO SURPRISES  — Pre-flight validates everything before first byte
#    2. OBSERVABILITY   — Real-time console progress + redacted log file
#    3. AUDITABILITY    — JSON manifest written after every run
#    4. IDEMPOTENT      — Safe to re-run; overwrites only if source is newer
#    5. RESUMABLE       — Auto-resumes interrupted AzCopy jobs on retry
#    6. SECURE          — SAS tokens never appear in logs or manifests
#    7. PORTABLE        — Runs in Git Bash, WSL, Linux, macOS, Docker, CI/CD
#
#  Usage:
#    bash azcopy_production_copy.sh --config ./copy_config.env
#    bash azcopy_production_copy.sh --config ./copy_config.env --dry-run
#    bash azcopy_production_copy.sh --config ./copy_config.env --no-confirm
#
#  Exit Codes:
#    0  — All paths copied and verified successfully
#    1  — Configuration / argument error
#    2  — Authentication failure
#    3  — Pre-flight check failed (AzCopy missing, source unreachable)
#    4  — One or more paths failed to copy after all retries
#    5  — Copy succeeded but post-copy verification failed
#    99 — Dry run completed (no data was copied)
#
#===============================================================================

# We intentionally do NOT use 'set -e'.  The retry loop, verification, and
# arithmetic increments all produce non-zero exits that we handle explicitly.
# 'set -u' catches unset variables.  'pipefail' ensures we see pipe failures.
set -uo pipefail

#===============================================================================
# CONSTANTS
#===============================================================================
readonly SCRIPT_VERSION="3.0.0"
readonly SCRIPT_NAME="$(basename "$0")"
readonly SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
readonly RUN_ID="$(date -u +%Y%m%dT%H%M%SZ)_$$"
readonly LOG_DIR="${SCRIPT_DIR}/logs"
readonly LOG_FILE="${LOG_DIR}/azcopy_${RUN_ID}.log"
readonly MANIFEST_FILE="${LOG_DIR}/manifest_${RUN_ID}.json"
readonly MIN_AZCOPY_VERSION="10.16"

#===============================================================================
# DEFAULT CONFIGURATION
# Override via config file (--config), environment variables, or CLI flags.
# Precedence: CLI flag > config file > environment variable > default below.
#===============================================================================

# ── Authentication ──
AUTH_MODE="${AUTH_MODE:-sas}"                       # sas | aad | spn
SPN_CLIENT_ID="${SPN_CLIENT_ID:-}"
SPN_TENANT_ID="${SPN_TENANT_ID:-}"
SPN_CLIENT_SECRET="${SPN_CLIENT_SECRET:-}"

# ── Source ──
SOURCE_ACCOUNT="${SOURCE_ACCOUNT:-}"
SOURCE_CONTAINER="${SOURCE_CONTAINER:-}"
SOURCE_SAS_TOKEN="${SOURCE_SAS_TOKEN:-}"

# ── Target ──
TARGET_ACCOUNT="${TARGET_ACCOUNT:-}"
TARGET_CONTAINER="${TARGET_CONTAINER:-}"
TARGET_SAS_TOKEN="${TARGET_SAS_TOKEN:-}"

# ── Storage Endpoint ──
# "blob" → .blob.core.windows.net  (standard Blob / flat namespace)
# "dfs"  → .dfs.core.windows.net   (ADLS Gen2 / hierarchical namespace)
STORAGE_ENDPOINT="${STORAGE_ENDPOINT:-blob}"

# ── Paths to Copy (semicolon-separated for batch) ──
COPY_PATHS="${COPY_PATHS:-}"

# ── Copy Behaviour ──
COPY_MODE="${COPY_MODE:-copy}"                     # copy | sync
RECURSIVE="${RECURSIVE:-true}"
OVERWRITE="${OVERWRITE:-ifSourceNewer}"             # true | false | ifSourceNewer | prompt
PUT_MD5="${PUT_MD5:-true}"
PRESERVE_ACCESS_TIER="${PRESERVE_ACCESS_TIER:-true}"
PRESERVE_PROPERTIES="${PRESERVE_PROPERTIES:-true}"
DELETE_DESTINATION="${DELETE_DESTINATION:-false}"   # sync mode only
LOG_LEVEL="${LOG_LEVEL:-INFO}"                     # INFO | WARNING | ERROR | DEBUG

# ── Filtering ──
INCLUDE_PATTERN="${INCLUDE_PATTERN:-}"             # e.g. "*.parquet;*.delta"
EXCLUDE_PATTERN="${EXCLUDE_PATTERN:-}"             # e.g. "_SUCCESS;_committed_*"

# ── Throughput ──
CAP_MBPS="${CAP_MBPS:-0}"                          # 0 = unlimited
CONCURRENCY="${CONCURRENCY:-0}"                    # 0 = auto-detect

# ── Retry ──
MAX_RETRIES="${MAX_RETRIES:-3}"
RETRY_WAIT_SECONDS="${RETRY_WAIT_SECONDS:-30}"

# ── Verification ──
VERIFY_AFTER_COPY="${VERIFY_AFTER_COPY:-true}"

# ── Operational ──
DRY_RUN="${DRY_RUN:-false}"
SKIP_CONFIRM="${SKIP_CONFIRM:-false}"              # true for CI/CD pipelines
NOTIFICATION_WEBHOOK="${NOTIFICATION_WEBHOOK:-}"   # Teams / Slack webhook URL

#===============================================================================
# TERMINAL COLORS  (auto-disabled when piped or redirected)
#===============================================================================
if [[ -t 1 ]]; then
    readonly C_RED='\033[0;31m'  C_GREEN='\033[0;32m'  C_YELLOW='\033[1;33m'
    readonly C_CYAN='\033[0;36m' C_BOLD='\033[1m'      C_NC='\033[0m'
else
    readonly C_RED='' C_GREEN='' C_YELLOW='' C_CYAN='' C_BOLD='' C_NC=''
fi

#===============================================================================
# LOGGING — all writes to log file are SAS-redacted automatically
#===============================================================================
mkdir -p "$LOG_DIR" 2>/dev/null || true

# Strip SAS tokens from any string before persisting to disk.
redact() {
    sed -E 's/\?s[ve]=[^"& ]*/?***REDACTED***/g; s/sig=[^"& ]*/sig=***REDACTED***/g' <<< "$1"
}

# Central logger — writes to both console (coloured) and log file (redacted).
log() {
    local level="$1"; shift
    local msg="$*"
    local ts
    ts="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

    # Log file — always redacted
    printf '[%s] [%-5s] %s\n' "$ts" "$level" "$(redact "$msg")" >> "$LOG_FILE" 2>/dev/null || true

    # Console — coloured
    case "$level" in
        INFO)  printf '%b[INFO ]%b %s\n' "$C_CYAN"   "$C_NC" "$msg" ;;
        OK)    printf '%b[ OK  ]%b %s\n' "$C_GREEN"  "$C_NC" "$msg" ;;
        WARN)  printf '%b[WARN ]%b %s\n' "$C_YELLOW" "$C_NC" "$msg" ;;
        ERROR) printf '%b[ERROR]%b %s\n' "$C_RED"    "$C_NC" "$msg" ;;
        DEBUG) [[ "$LOG_LEVEL" == "DEBUG" ]] && printf '[DEBUG] %s\n' "$msg" || true ;;
        *)     printf '%s\n' "$msg" ;;
    esac
}

die() {
    log ERROR "$1"
    send_notification "FAILED" "$1"
    exit "${2:-1}"
}

#===============================================================================
# TRAP — clean exit on interrupt / termination
#===============================================================================
cleanup() {
    local sig="${1:-UNKNOWN}"
    log WARN "Caught signal: $sig — aborting"
    send_notification "ABORTED" "Script interrupted by signal $sig after partial execution"
    # Write partial manifest
    write_manifest "ABORTED" "0" "0" "0" "0"
    exit 130
}
trap 'cleanup INT'  INT
trap 'cleanup TERM' TERM

#===============================================================================
# NOTIFICATION — Teams / Slack compatible payload
#===============================================================================
send_notification() {
    local status="$1"
    local message="$2"
    [[ -z "${NOTIFICATION_WEBHOOK:-}" ]] && return 0

    # JSON-safe escaping: replace backslash, quotes, newlines
    local safe_msg
    safe_msg=$(printf '%s' "$message" | sed 's/\\/\\\\/g; s/"/\\"/g; s/$/\\n/g' | tr -d '\n')

    local payload
    payload=$(printf '{"text":"AzCopy %s\\n\\nSource: %s/%s\\nTarget: %s/%s\\n\\n%s\\n\\nRun: %s"}' \
        "$status" "$SOURCE_ACCOUNT" "$SOURCE_CONTAINER" \
        "$TARGET_ACCOUNT" "$TARGET_CONTAINER" \
        "$safe_msg" "$RUN_ID")

    curl -s -X POST -H "Content-Type: application/json" \
        -d "$payload" "$NOTIFICATION_WEBHOOK" \
        --connect-timeout 10 --max-time 30 > /dev/null 2>&1 || true
}

#===============================================================================
# MANIFEST — JSON audit trail written after every run
#===============================================================================
write_manifest() {
    local status="$1" succeeded="$2" failed="$3" skipped="$4" duration="$5"
    shift 5
    local results=("$@")

    local paths_json="["
    local first=true
    for r in "${results[@]}"; do
        if [[ "$first" == "true" ]]; then first=false; else paths_json+=","; fi
        paths_json+="$(printf '"%s"' "$(redact "$r")")"
    done
    paths_json+="]"

    cat > "$MANIFEST_FILE" <<-MANIFEST
{
  "run_id": "${RUN_ID}",
  "version": "${SCRIPT_VERSION}",
  "status": "${status}",
  "timestamp": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "source": {
    "account": "${SOURCE_ACCOUNT}",
    "container": "${SOURCE_CONTAINER}",
    "endpoint": "${STORAGE_ENDPOINT}"
  },
  "target": {
    "account": "${TARGET_ACCOUNT}",
    "container": "${TARGET_CONTAINER}",
    "endpoint": "${STORAGE_ENDPOINT}"
  },
  "config": {
    "auth_mode": "${AUTH_MODE}",
    "copy_mode": "${COPY_MODE}",
    "recursive": ${RECURSIVE},
    "overwrite": "${OVERWRITE}",
    "put_md5": ${PUT_MD5},
    "dry_run": ${DRY_RUN},
    "max_retries": ${MAX_RETRIES}
  },
  "results": {
    "total_paths": $((succeeded + failed + skipped)),
    "succeeded": ${succeeded},
    "failed": ${failed},
    "skipped": ${skipped},
    "duration_seconds": ${duration}
  },
  "paths": ${paths_json},
  "log_file": "$(basename "$LOG_FILE")"
}
MANIFEST
    log DEBUG "Manifest written: $MANIFEST_FILE"
}

#===============================================================================
# BANNER
#===============================================================================
print_banner() {
    echo ""
    printf '%b================================================================%b\n' "$C_CYAN" "$C_NC"
    printf '%b  AzCopy Universal Storage Copy                    v%s%b\n' "$C_CYAN" "$SCRIPT_VERSION" "$C_NC"
    printf '%b================================================================%b\n' "$C_CYAN" "$C_NC"
    printf '  Mode: %b%s%b | Auth: %b%s%b | Endpoint: %b%s%b | Dry Run: %b%s%b\n' \
        "$C_BOLD" "$COPY_MODE" "$C_NC" \
        "$C_BOLD" "$AUTH_MODE" "$C_NC" \
        "$C_BOLD" "$STORAGE_ENDPOINT" "$C_NC" \
        "$C_BOLD" "$DRY_RUN" "$C_NC"
    printf '%b================================================================%b\n' "$C_CYAN" "$C_NC"
    echo ""
}

#===============================================================================
# CLI ARGUMENT PARSER
#===============================================================================
parse_args() {
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --config)
                [[ -z "${2:-}" || ! -f "$2" ]] && { echo "[ERROR] Config file not found: ${2:-<missing>}"; exit 1; }
                # shellcheck source=/dev/null
                source "$2"; shift 2 ;;
            --auth-mode)         AUTH_MODE="$2";          shift 2 ;;
            --source-account)    SOURCE_ACCOUNT="$2";     shift 2 ;;
            --source-container)  SOURCE_CONTAINER="$2";   shift 2 ;;
            --source-sas)        SOURCE_SAS_TOKEN="$2";   shift 2 ;;
            --target-account)    TARGET_ACCOUNT="$2";     shift 2 ;;
            --target-container)  TARGET_CONTAINER="$2";   shift 2 ;;
            --target-sas)        TARGET_SAS_TOKEN="$2";   shift 2 ;;
            --paths)             COPY_PATHS="$2";         shift 2 ;;
            --mode)              COPY_MODE="$2";          shift 2 ;;
            --endpoint)          STORAGE_ENDPOINT="$2";   shift 2 ;;
            --include-pattern)   INCLUDE_PATTERN="$2";    shift 2 ;;
            --exclude-pattern)   EXCLUDE_PATTERN="$2";    shift 2 ;;
            --cap-mbps)          CAP_MBPS="$2";           shift 2 ;;
            --concurrency)       CONCURRENCY="$2";        shift 2 ;;
            --dry-run)           DRY_RUN="true";          shift ;;
            --no-confirm)        SKIP_CONFIRM="true";     shift ;;
            --retries)           MAX_RETRIES="$2";        shift 2 ;;
            --webhook)           NOTIFICATION_WEBHOOK="$2"; shift 2 ;;
            --help|-h)           show_help; exit 0 ;;
            *)
                echo "[ERROR] Unknown argument: $1"
                echo "Run '$SCRIPT_NAME --help' for usage."
                exit 1 ;;
        esac
    done
}

show_help() {
    cat <<'HELP'
AzCopy Universal Storage Copy — v3.0.0

AUTHENTICATION:
  --auth-mode MODE         sas (default) | aad | spn
  --source-sas TOKEN       SAS token for source account
  --target-sas TOKEN       SAS token for target account

STORAGE:
  --source-account NAME    Source storage account name
  --source-container NAME  Source container name
  --target-account NAME    Target storage account name
  --target-container NAME  Target container name
  --endpoint TYPE          blob (default) | dfs (ADLS Gen2)
  --paths "p1;p2;p3"      Semicolon-separated paths to copy

COPY BEHAVIOUR:
  --mode copy|sync         Copy mode (default: copy)
  --include-pattern PAT    Include only matching files (e.g. "*.parquet")
  --exclude-pattern PAT    Exclude matching files (e.g. "_SUCCESS;*.crc")

THROUGHPUT:
  --cap-mbps N             Bandwidth cap in Mbps (0 = unlimited)
  --concurrency N          Parallel connections (0 = auto)

OPERATIONAL:
  --config FILE            Load configuration from .env file
  --dry-run                List files only — no copy performed
  --no-confirm             Skip confirmation prompt (CI/CD mode)
  --retries N              Max retry attempts per path (default: 3)
  --webhook URL            Teams/Slack notification webhook

  --help                   Show this help message

EXAMPLES:
  # Basic copy with config file
  bash azcopy_production_copy.sh --config ./copy_config.env

  # Dry run to preview what would be copied
  bash azcopy_production_copy.sh --config ./copy_config.env --dry-run

  # Copy only parquet files, cap at 500 Mbps
  bash azcopy_production_copy.sh --config ./copy_config.env \
    --include-pattern "*.parquet" --cap-mbps 500

  # ADLS Gen2 endpoint (hierarchical namespace)
  bash azcopy_production_copy.sh --config ./copy_config.env --endpoint dfs
HELP
}

#===============================================================================
# PRE-FLIGHT CHECKS
#===============================================================================
preflight_check_azcopy() {
    log INFO "Pre-flight: checking AzCopy installation..."

    # Standard PATH check
    if command -v azcopy &> /dev/null; then
        local ver_str
        ver_str=$(azcopy --version 2>&1)
        log OK "AzCopy found: $ver_str"
        return 0
    fi

    # Git Bash on Windows: try common install locations
    local candidates=(
        "/c/Users/${USER:-${USERNAME:-unknown}}/azcopy.exe"
        "$HOME/azcopy.exe"
        "/usr/local/bin/azcopy"
    )
    for candidate in "${candidates[@]}"; do
        if [[ -f "$candidate" ]]; then
            export PATH="$PATH:$(dirname "$candidate")"
            log OK "AzCopy found at $candidate: $(azcopy --version 2>&1)"
            return 0
        fi
    done

    die "AzCopy not found in PATH. Install: powershell -ExecutionPolicy Bypass -File install_azcopy.ps1" 3
}

preflight_check_config() {
    log INFO "Pre-flight: validating configuration..."
    local err=0

    # Required fields
    [[ -z "$SOURCE_ACCOUNT" ]]   && { log ERROR "SOURCE_ACCOUNT is required";   err=$((err+1)); }
    [[ -z "$SOURCE_CONTAINER" ]] && { log ERROR "SOURCE_CONTAINER is required"; err=$((err+1)); }
    [[ -z "$TARGET_ACCOUNT" ]]   && { log ERROR "TARGET_ACCOUNT is required";   err=$((err+1)); }
    [[ -z "$TARGET_CONTAINER" ]] && { log ERROR "TARGET_CONTAINER is required"; err=$((err+1)); }
    [[ -z "$COPY_PATHS" ]]       && { log ERROR "COPY_PATHS is required";       err=$((err+1)); }

    # Auth-specific validation
    case "$AUTH_MODE" in
        sas)
            [[ -z "$SOURCE_SAS_TOKEN" ]] && { log ERROR "SOURCE_SAS_TOKEN required for SAS auth"; err=$((err+1)); }
            [[ -z "$TARGET_SAS_TOKEN" ]] && { log ERROR "TARGET_SAS_TOKEN required for SAS auth"; err=$((err+1)); }
            ;;
        spn)
            [[ -z "$SPN_CLIENT_ID" ]]     && { log ERROR "SPN_CLIENT_ID required for SPN auth";     err=$((err+1)); }
            [[ -z "$SPN_TENANT_ID" ]]     && { log ERROR "SPN_TENANT_ID required for SPN auth";     err=$((err+1)); }
            [[ -z "$SPN_CLIENT_SECRET" ]] && { log ERROR "SPN_CLIENT_SECRET required for SPN auth"; err=$((err+1)); }
            ;;
        aad) ;;  # No extra fields needed
        *)  log ERROR "AUTH_MODE must be sas|aad|spn (got: '$AUTH_MODE')"; err=$((err+1)) ;;
    esac

    # Enum validation
    [[ "$COPY_MODE" != "copy" && "$COPY_MODE" != "sync" ]] && \
        { log ERROR "COPY_MODE must be copy|sync (got: '$COPY_MODE')"; err=$((err+1)); }
    [[ "$STORAGE_ENDPOINT" != "blob" && "$STORAGE_ENDPOINT" != "dfs" ]] && \
        { log ERROR "STORAGE_ENDPOINT must be blob|dfs (got: '$STORAGE_ENDPOINT')"; err=$((err+1)); }

    [[ $err -gt 0 ]] && die "Configuration validation failed ($err error(s)). Fix and re-run." 1
    log OK "Configuration valid — $AUTH_MODE auth, $COPY_MODE mode, $STORAGE_ENDPOINT endpoint"
}

preflight_check_sas_expiry() {
    [[ "$AUTH_MODE" != "sas" ]] && return 0

    log INFO "Pre-flight: checking SAS token expiry..."
    local now_epoch
    now_epoch=$(date -u +%s)

    for label_token in "Source:$SOURCE_SAS_TOKEN" "Target:$TARGET_SAS_TOKEN"; do
        local label="${label_token%%:*}"
        local token="${label_token#*:}"

        # Extract 'se=' (SignedExpiry) from the SAS token
        local expiry=""
        if [[ "$token" =~ se=([^&]+) ]]; then
            expiry="${BASH_REMATCH[1]}"
            # URL-decode %3A → : and %2F → / (common in SAS tokens)
            expiry="${expiry//%3A/:}"
            expiry="${expiry//%2F//}"
            expiry="${expiry//%3a/:}"
            expiry="${expiry//%2f//}"
        fi

        if [[ -z "$expiry" ]]; then
            log WARN "$label SAS: no 'se=' (expiry) found — cannot check validity"
            continue
        fi

        # Parse expiry to epoch (portable: works on GNU date and BSD date)
        local exp_epoch=0
        if exp_epoch=$(date -u -d "$expiry" +%s 2>/dev/null); then
            : # GNU date succeeded
        elif exp_epoch=$(date -u -j -f "%Y-%m-%dT%H:%M:%SZ" "$expiry" +%s 2>/dev/null); then
            : # BSD date succeeded
        else
            log WARN "$label SAS: could not parse expiry '$expiry' — skipping check"
            continue
        fi

        local remaining=$(( exp_epoch - now_epoch ))
        if [[ $remaining -le 0 ]]; then
            die "$label SAS token EXPIRED on $expiry. Generate a new token and re-run." 3
        elif [[ $remaining -lt 3600 ]]; then
            log WARN "$label SAS token expires in $((remaining / 60)) minutes — consider renewing"
        else
            local hours=$(( remaining / 3600 ))
            log OK "$label SAS token valid (expires in ${hours}h)"
        fi
    done
}

preflight_check_source_reachable() {
    log INFO "Pre-flight: verifying source is reachable..."

    # Build a probe URL for the first path
    IFS=';' read -ra probe_paths <<< "$COPY_PATHS"
    local first_path="${probe_paths[0]}"
    first_path="${first_path#"${first_path%%[![:space:]]*}"}"
    first_path="${first_path%"${first_path##*[![:space:]]}"}"

    local src_sas=""
    [[ "$AUTH_MODE" == "sas" ]] && src_sas="$SOURCE_SAS_TOKEN"

    local probe_url
    probe_url=$(build_url "$SOURCE_ACCOUNT" "$SOURCE_CONTAINER" "$first_path" "$src_sas")

    # Attempt to list 1 file — confirms auth + connectivity
    if azcopy list "$probe_url" --running-tally 2>&1 | head -3 | grep -qi "error\|fail\|AuthenticationFailed\|AuthorizationFailure"; then
        die "Cannot reach source: ${SOURCE_ACCOUNT}/${SOURCE_CONTAINER}/${first_path}/. Check account name, SAS token, and network." 3
    fi
    log OK "Source reachable — ${SOURCE_ACCOUNT}/${SOURCE_CONTAINER}/${first_path}/"
}

#===============================================================================
# AUTHENTICATION
#===============================================================================
authenticate() {
    case "$AUTH_MODE" in
        sas)
            log INFO "Auth mode: SAS tokens (no interactive login needed)"
            ;;
        aad)
            log INFO "Auth mode: Azure AD — launching browser sign-in..."
            # We do NOT pipe through tee here — azcopy login is interactive
            if ! azcopy login; then
                die "Azure AD login failed. Ensure 'Storage Blob Data Reader/Contributor' RBAC roles." 2
            fi
            log OK "Azure AD login completed"
            ;;
        spn)
            log INFO "Auth mode: Service Principal"
            export AZCOPY_SPA_CLIENT_SECRET="$SPN_CLIENT_SECRET"
            if ! azcopy login --service-principal \
                --application-id "$SPN_CLIENT_ID" \
                --tenant-id "$SPN_TENANT_ID" 2>&1; then
                die "Service Principal login failed. Verify client ID, tenant ID, and secret." 2
            fi
            log OK "Service Principal authenticated"
            ;;
    esac
}

#===============================================================================
# URL BUILDER — endpoint-aware, slash-safe, SAS-normalized
#===============================================================================
build_url() {
    local account="$1"
    local container="$2"
    local path="$3"
    local sas_token="${4:-}"

    # Choose endpoint: blob.core.windows.net or dfs.core.windows.net
    local domain="${STORAGE_ENDPOINT}.core.windows.net"
    local url="https://${account}.${domain}/${container}"

    # Append path — strip leading/trailing slashes to prevent //
    if [[ -n "$path" ]]; then
        path="${path#/}"
        path="${path%/}"
        url="${url}/${path}"
    fi

    # Trailing slash signals "this is a directory" to AzCopy
    url="${url}/"

    # Append SAS token (normalize: strip leading '?' — we add our own)
    if [[ -n "$sas_token" ]]; then
        sas_token="${sas_token#\?}"
        url="${url}?${sas_token}"
    fi

    printf '%s' "$url"
}

#===============================================================================
# FILE COUNTING — robust, version-independent
#===============================================================================
count_files_at_url() {
    local url="$1"
    local output count

    # azcopy list with --running-tally prints a "File count: N" summary line.
    # This is more reliable than grep-counting individual file lines.
    output=$(azcopy list "$url" --running-tally 2>&1) || true

    # Try the summary line first (AzCopy v10.16+)
    if count=$(grep -oiP 'File count:\s*\K\d+' <<< "$output" 2>/dev/null); then
        printf '%s' "$count"
        return 0
    fi

    # Fallback: count lines containing "Content Length" (works on all versions)
    count=$(grep -c "Content Length" <<< "$output" 2>/dev/null) || count=0
    printf '%s' "$count"
}

#===============================================================================
# SIZE ESTIMATION — show total bytes before copy
#===============================================================================
estimate_size_at_url() {
    local url="$1"
    local output total_bytes

    output=$(azcopy list "$url" --running-tally 2>&1) || true

    # Try to extract total size from running tally (AzCopy v10.16+)
    if total_bytes=$(grep -oiP 'Total file size:\s*\K[0-9.]+\s*\S+' <<< "$output" 2>/dev/null); then
        printf '%s' "$total_bytes"
        return 0
    fi

    printf 'unknown'
}

#===============================================================================
# COPY SINGLE PATH — retry loop with resume, progress display, verification
#===============================================================================
copy_single_path() {
    local path="$1"
    local path_index="$2"
    local total_paths="$3"
    local attempt=0
    local copy_succeeded=false
    local verify_succeeded=true

    # Build URLs
    local src_sas="" tgt_sas=""
    [[ "$AUTH_MODE" == "sas" ]] && { src_sas="$SOURCE_SAS_TOKEN"; tgt_sas="$TARGET_SAS_TOKEN"; }

    local source_url target_url
    source_url=$(build_url "$SOURCE_ACCOUNT" "$SOURCE_CONTAINER" "$path" "$src_sas")
    target_url=$(build_url "$TARGET_ACCOUNT" "$TARGET_CONTAINER" "$path" "$tgt_sas")

    log INFO "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    log INFO "[${path_index}/${total_paths}] Path: $path"
    log INFO "  Source: ${SOURCE_ACCOUNT}/${SOURCE_CONTAINER}/${path}/"
    log INFO "  Target: ${TARGET_ACCOUNT}/${TARGET_CONTAINER}/${path}/"

    # ── Dry Run ──
    if [[ "$DRY_RUN" == "true" ]]; then
        log INFO "[DRY RUN] Listing source files..."
        local count size
        count=$(count_files_at_url "$source_url")
        size=$(estimate_size_at_url "$source_url")
        log INFO "[DRY RUN] Files: $count | Size: $size — no copy performed"
        echo "DRY_RUN|${path}|${count}|${size}"
        return 0
    fi

    # ── Pre-copy: Source inventory ──
    log INFO "Scanning source..."
    local src_count src_size
    src_count=$(count_files_at_url "$source_url")
    src_size=$(estimate_size_at_url "$source_url")
    log INFO "Source: $src_count files, $src_size"

    if [[ "$src_count" == "0" ]]; then
        log WARN "No files at source — skipping"
        echo "SKIPPED|${path}|0|0"
        return 0
    fi

    # ── Build AzCopy argument list ──
    local azcopy_args=()

    # Core flags
    [[ "$RECURSIVE" == "true" ]]           && azcopy_args+=("--recursive")
    azcopy_args+=("--overwrite=${OVERWRITE}")
    [[ "$PUT_MD5" == "true" ]]             && azcopy_args+=("--put-md5")
    azcopy_args+=("--log-level=${LOG_LEVEL}")

    # Avoid creating nested destination folders like CART_LINES/CART_LINES/...
    # AzCopy default is --as-subdir=true for folder sources.
    [[ "$COPY_MODE" == "copy" ]] && azcopy_args+=("--as-subdir=false")

    # Server-to-server preservation (critical for production)
    [[ "$PRESERVE_ACCESS_TIER" == "true" ]] && azcopy_args+=("--s2s-preserve-access-tier=true")
    [[ "$PRESERVE_PROPERTIES" == "true" ]]  && azcopy_args+=("--s2s-preserve-properties=true")

    # Sync-mode flags
    [[ "$COPY_MODE" == "sync" ]] && azcopy_args+=("--delete-destination=${DELETE_DESTINATION}")

    # Filtering
    [[ -n "$INCLUDE_PATTERN" ]] && azcopy_args+=("--include-pattern=${INCLUDE_PATTERN}")
    [[ -n "$EXCLUDE_PATTERN" ]] && azcopy_args+=("--exclude-pattern=${EXCLUDE_PATTERN}")

    # Throughput
    [[ "$CAP_MBPS" != "0" ]] && azcopy_args+=("--cap-mbps=${CAP_MBPS}")

    # ── Concurrency (environment variable, not a flag) ──
    if [[ "$CONCURRENCY" != "0" ]]; then
        export AZCOPY_CONCURRENCY_VALUE="$CONCURRENCY"
        log DEBUG "Concurrency set to $CONCURRENCY"
    fi

    # ── Retry loop ──
    while [[ $attempt -lt $MAX_RETRIES ]]; do
        attempt=$((attempt + 1))
        log INFO "Attempt $attempt of $MAX_RETRIES..."

        local attempt_log="${LOG_DIR}/azcopy_attempt_${RUN_ID}_${path_index}_${attempt}.log"

        # ── Execute AzCopy ──
        # We use a subshell + explicit exit code capture to avoid PIPESTATUS issues.
        # The `tee` sends output to BOTH console (user sees progress) AND log file.
        local azcopy_exit=0
        {
            azcopy "$COPY_MODE" "$source_url" "$target_url" "${azcopy_args[@]}" 2>&1
            echo "AZCOPY_EXIT:$?"
        } | tee "$attempt_log" | while IFS= read -r line; do
            # Redact SAS tokens from console output
            redact "$line"
            # Also append redacted line to main log
            printf '%s\n' "$(redact "$line")" >> "$LOG_FILE" 2>/dev/null || true
        done

        # Extract the real exit code from the last line of the attempt log
        if grep -q "AZCOPY_EXIT:0" "$attempt_log" 2>/dev/null; then
            azcopy_exit=0
        else
            azcopy_exit=$(grep -oP 'AZCOPY_EXIT:\K\d+' "$attempt_log" 2>/dev/null | tail -1) || azcopy_exit=1
        fi

        if [[ "$azcopy_exit" -eq 0 ]]; then
            copy_succeeded=true
            break
        fi

        log WARN "Attempt $attempt failed (exit code: $azcopy_exit)"

        # Check for partial transfer
        if grep -q "Transfers Completed.*[1-9]" "$attempt_log" 2>/dev/null; then
            log INFO "Partial transfer detected — will attempt resume"
        fi

        # Wait + retry
        if [[ $attempt -lt $MAX_RETRIES ]]; then
            local wait_secs=$((RETRY_WAIT_SECONDS * attempt))
            log INFO "Backoff: waiting ${wait_secs}s before retry..."
            sleep "$wait_secs"

            # Attempt job resume first (faster than full re-copy)
            local job_id
            job_id=$(azcopy jobs list 2>/dev/null | grep -oP 'JobId: \K\S+' | head -1) || true
            if [[ -n "${job_id:-}" ]]; then
                log INFO "Resuming AzCopy job $job_id..."
                if azcopy jobs resume "$job_id" 2>&1 | tee -a "$LOG_FILE" | head -5; then
                    copy_succeeded=true
                    break
                fi
                log WARN "Resume failed — falling back to full retry"
            fi
        fi
    done

    if [[ "$copy_succeeded" != "true" ]]; then
        log ERROR "FAILED after $MAX_RETRIES attempts: $path"
        echo "FAILED|${path}|${src_count}|0"
        return 1
    fi

    log OK "Copy completed: $path"

    # ── Post-copy verification ──
    if [[ "$VERIFY_AFTER_COPY" == "true" ]]; then
        log INFO "Verifying target..."
        local tgt_count
        tgt_count=$(count_files_at_url "$target_url")
        log INFO "Verification: source=$src_count files, target=$tgt_count files"

        if [[ "$src_count" == "$tgt_count" ]]; then
            log OK "Verified: file counts match ($src_count)"
        elif [[ "$tgt_count" -gt "$src_count" ]]; then
            log WARN "Target has MORE files ($tgt_count > $src_count) — pre-existing data at target"
        else
            log ERROR "VERIFICATION FAILED: source=$src_count, target=$tgt_count — mismatch"
            verify_succeeded=false
        fi
    fi

    if [[ "$verify_succeeded" != "true" ]]; then
        echo "VERIFY_FAIL|${path}|${src_count}|${tgt_count:-0}"
        return 1
    fi

    echo "OK|${path}|${src_count}|${src_count}"
    return 0
}

#===============================================================================
# MAIN
#===============================================================================
main() {
    parse_args "$@"
    print_banner

    log INFO "Run ID   : $RUN_ID"
    log INFO "Log file : $LOG_FILE"
    log INFO "Manifest : $MANIFEST_FILE"
    log INFO ""

    # ── Pre-flight ──
    preflight_check_azcopy
    preflight_check_config
    preflight_check_sas_expiry
    authenticate
    preflight_check_source_reachable

    # ── Parse paths ──
    IFS=';' read -ra PATHS <<< "$COPY_PATHS"
    # Trim whitespace from each path (POSIX-safe, no xargs)
    local cleaned_paths=()
    for p in "${PATHS[@]}"; do
        p="${p#"${p%%[![:space:]]*}"}"
        p="${p%"${p##*[![:space:]]}"}"
        # Normalize common user input: treat a trailing '/*' as "the directory".
        # The URL builder always appends '/', so keeping '/*' would become '*/' and match nothing.
        if [[ "$p" == */\* ]]; then
            p="${p%/\*}"
        fi
        [[ -n "$p" ]] && cleaned_paths+=("$p")
    done
    PATHS=("${cleaned_paths[@]}")
    local total_paths=${#PATHS[@]}

    # ── Show copy plan ──
    log INFO ""
    log INFO "======================== COPY PLAN ========================"
    log INFO "  Source   : ${SOURCE_ACCOUNT}.${STORAGE_ENDPOINT}.core.windows.net/${SOURCE_CONTAINER}"
    log INFO "  Target   : ${TARGET_ACCOUNT}.${STORAGE_ENDPOINT}.core.windows.net/${TARGET_CONTAINER}"
    log INFO "  Paths    : ${total_paths}"
    log INFO "  Mode     : ${COPY_MODE} | Auth: ${AUTH_MODE}"
    log INFO "  Retries  : ${MAX_RETRIES} | Verify: ${VERIFY_AFTER_COPY}"
    [[ -n "$INCLUDE_PATTERN" ]] && log INFO "  Include  : ${INCLUDE_PATTERN}"
    [[ -n "$EXCLUDE_PATTERN" ]] && log INFO "  Exclude  : ${EXCLUDE_PATTERN}"
    [[ "$CAP_MBPS" != "0" ]]    && log INFO "  Cap      : ${CAP_MBPS} Mbps"
    [[ "$CONCURRENCY" != "0" ]] && log INFO "  Workers  : ${CONCURRENCY}"
    [[ "$DRY_RUN" == "true" ]]  && log WARN "  *** DRY RUN — no data will be copied ***"
    log INFO "==========================================================="
    log INFO ""

    for i in "${!PATHS[@]}"; do
        log INFO "  [$((i+1))/$total_paths] ${PATHS[$i]}"
    done
    log INFO ""

    # ── Confirmation ──
    if [[ "$SKIP_CONFIRM" != "true" && "$DRY_RUN" != "true" ]]; then
        read -rp "Proceed with copy? (Y/n): " confirm
        if [[ "${confirm:-Y}" =~ ^[nN] ]]; then
            log INFO "Cancelled by user."
            exit 0
        fi
    fi

    # ── Execute ──
    send_notification "STARTED" "Copying ${total_paths} path(s)"

    local start_time succeeded=0 failed=0 skipped=0 verify_failed=0
    start_time=$(date +%s)
    declare -a RESULTS=()

    for i in "${!PATHS[@]}"; do
        local path="${PATHS[$i]}"
        local idx=$((i + 1))

        log INFO ""
        local result_line=""
        if result_line=$(copy_single_path "$path" "$idx" "$total_paths"); then
            local status="${result_line%%|*}"
            case "$status" in
                OK)       succeeded=$((succeeded + 1)); RESULTS+=("[  OK  ] $path") ;;
                DRY_RUN)  skipped=$((skipped + 1));     RESULTS+=("[DRY  ] $path") ;;
                SKIPPED)  skipped=$((skipped + 1));     RESULTS+=("[SKIP ] $path") ;;
                *)        succeeded=$((succeeded + 1)); RESULTS+=("[  OK  ] $path") ;;
            esac
        else
            local status="${result_line%%|*}"
            case "$status" in
                VERIFY_FAIL) verify_failed=$((verify_failed + 1)); RESULTS+=("[VFAIL] $path") ;;
                *)           failed=$((failed + 1));               RESULTS+=("[FAIL ] $path") ;;
            esac
        fi
    done

    # ── Summary ──
    local end_time duration minutes seconds
    end_time=$(date +%s)
    duration=$((end_time - start_time))
    minutes=$((duration / 60))
    seconds=$((duration % 60))

    log INFO ""
    log INFO "========================= SUMMARY ========================="
    log INFO "  Total paths   : ${total_paths}"
    log INFO "  Succeeded     : ${succeeded}"
    log INFO "  Failed        : ${failed}"
    log INFO "  Verify failed : ${verify_failed}"
    log INFO "  Skipped       : ${skipped}"
    log INFO "  Duration      : ${minutes}m ${seconds}s"
    log INFO "  Log file      : ${LOG_FILE}"
    log INFO "  Manifest      : ${MANIFEST_FILE}"
    log INFO "-----------------------------------------------------------"
    for r in "${RESULTS[@]}"; do
        log INFO "  $r"
    done
    log INFO "==========================================================="
    log INFO ""

    # ── Write manifest ──
    write_manifest \
        "$(if [[ $failed -gt 0 || $verify_failed -gt 0 ]]; then echo "PARTIAL_FAILURE"; elif [[ "$DRY_RUN" == "true" ]]; then echo "DRY_RUN"; else echo "SUCCESS"; fi)" \
        "$succeeded" "$failed" "$skipped" "$duration" \
        "${RESULTS[@]}"

    # ── Final exit ──
    if [[ "$DRY_RUN" == "true" ]]; then
        log OK "Dry run completed. No data was copied."
        send_notification "DRY RUN" "${total_paths} path(s) scanned in ${minutes}m ${seconds}s"
        exit 99
    elif [[ $verify_failed -gt 0 && $failed -eq 0 ]]; then
        log ERROR "${verify_failed} path(s) copied but FAILED verification. Check manifest."
        send_notification "VERIFY FAILED" "${verify_failed}/${total_paths} failed verification in ${minutes}m ${seconds}s"
        exit 5
    elif [[ $failed -gt 0 ]]; then
        log ERROR "${failed} path(s) failed. Check log: $(basename "$LOG_FILE")"
        send_notification "PARTIAL FAILURE" "${succeeded} OK, ${failed} failed in ${minutes}m ${seconds}s"
        exit 4
    else
        log OK "All ${succeeded} path(s) copied and verified in ${minutes}m ${seconds}s"
        send_notification "SUCCESS" "All ${succeeded} path(s) copied in ${minutes}m ${seconds}s"
        exit 0
    fi
}

main "$@"
